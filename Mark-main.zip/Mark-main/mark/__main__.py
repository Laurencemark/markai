# Copyright (c) 2022 laurence mark

from pyrogram import idle
from . import markai

if __name__ == "__main__" :
    yuiai.start()
    print("Mark is live! Join @i_laurencemark")
    idle()