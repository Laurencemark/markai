# Copyright (c) 2021 Itz-fork

Emergency_Msgs = [
    "I'm not feeling well. I think i should go and sleep now.",
    "I have some work to do. Bye!",
    "I'm very tired. I need to take a nap.",
    "Ooops!, I think my owner forgot to pay my bill!",
    "Oh, I think something happened to me!",
    "Nice to meet you but I have to go now, Bye!"
]

Photo_Reesponse = [
    "Woah, that's a nice picture",
    "Hmmm... This one looks prettry good!",
    "What's this?",
    "IMHO This is the worst image I've ever seen in my life",
    "Pathetic...",
    "Ok? I guess",
    "I don't like photos :(",
    "This image is weird",
    "I don't know what to do with this image",
    "Hey, can we please chat only using text messages? because I can't understand photos correctly :("
]

Sticker_Response = [
    "Aww, nice sticker",
    "I like this sticker ngl.",
    "Who made this?",
    "This sticker looks terrible.",
    "Uhmmm... So what's up with this sticker?",
    "Ok, cool",
    "I love these types of stickers",
    "Can we please chat only using text messages? because I can't understand stickers correctly :("
]

Video_and_gif_Response = [
    "What is this?",
    "I don't wanna waste my data to download this file",
    "What do you want?",
    "Can you elborate?",
    "I don't watch videos",
    "Is this clip from a movie?",
    "uWu, this looks nice!",
    "I can't understand videos correctly :( . Let's chat only using text messages"
]

Document_Response = [
    "I don't wanna waste my data to download this file",
    "Sorry, what?",
    "What is this file anyway?",
    "Looks like this a virus '-'",
    "I don't like this",
    "Why did you send me this? Can't we use text messages to chat?"
]